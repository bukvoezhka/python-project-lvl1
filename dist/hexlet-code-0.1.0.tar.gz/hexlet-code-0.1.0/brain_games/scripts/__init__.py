"""Game script module."""
