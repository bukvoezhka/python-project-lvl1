"""Module of game scripts."""
