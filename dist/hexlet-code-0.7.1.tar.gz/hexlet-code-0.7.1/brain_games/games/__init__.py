"""Modules of games core."""
