"""Main init game module."""
