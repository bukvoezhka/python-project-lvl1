"""Game module for brain-calc."""
from random import choice, randint

operator = (' + ', ' - ', ' * ')


def brain_calc():
    a = str(randint(1, 25))
    b = str(randint(1, 25))
    return a + choice(operator) + b


def is_result(expression):
    expression = expression.split(' ')
    a = int(expression[0])
    b = int(expression[2])
    if '+' in expression:
        return str(a + b)
    if '-' in expression:
        return str(a - b)
    return str(a * b)
